Dataset for only optimized condition is provided.

For different number or rotations/pixel resoultion, follow the same instruction for data pre-processing as for the METLIN datasets