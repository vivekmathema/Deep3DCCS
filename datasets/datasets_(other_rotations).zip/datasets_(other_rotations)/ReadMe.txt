The 2d projection datasets for these SMILEs rotation needs to be created frist following same pre-processing steps as for the 5 rotation
