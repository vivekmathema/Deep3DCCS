import os
import pandas as pd

def replace_header_in_file(filepath):
    try:
        # -------- CSV FILES --------
        if filepath.lower().endswith(".csv"):
            df = pd.read_csv(filepath, encoding="latin-1")

            if "AllCCSID" in df.columns:
                df.rename(columns={"AllCCSID": "ID"}, inplace=True)
                df.to_csv(filepath, index=False, encoding="latin-1")
                print(f"Updated CSV: {filepath}")
            else:
                print(f"No change needed (CSV): {filepath}")

        # -------- XLS FILES --------
        elif filepath.lower().endswith(".xls"):
            df = pd.read_excel(filepath, engine="xlrd")

            if "AllCCSID" in df.columns:
                df.rename(columns={"AllCCSID": "ID"}, inplace=True)
                df.to_excel(filepath, index=False, engine="xlwt")
                print(f"Updated XLS: {filepath}")
            else:
                print(f"No change needed (XLS): {filepath}")

    except Exception as e:
        print(f"Error processing {filepath}: {e}")

# Process all CSV and XLS files in current directory
for file in os.listdir("."):
    if file.lower().endswith((".csv", ".xls")):
        replace_header_in_file(file)

print("Done.")
